# create-clean-react

Minimal React project initializer. Scaffolds a fresh Vite (or CRA) project and immediately strips the boilerplate — no spinning logo, no dead test files, no reportWebVitals.

## Usage

```bash
npx create-clean-react <project-name> [options]
```

## Options

| Flag | Description |
|------|-------------|
| `--cra` | Use Create React App instead of Vite (default: Vite) |
| `--ts` | Use TypeScript template |
| `--folders` | Generate standard folder structure under `src/` |

## Examples

```bash
# Vite + JavaScript
npx create-clean-react my-app

# Vite + TypeScript
npx create-clean-react my-app --ts

# CRA + TypeScript + folders
npx create-clean-react my-app --cra --ts --folders
```

## What it does

- Rewrites `App.jsx` / `App.tsx` with a clean shell component
- Rewrites `main.jsx` / `index.js` without dead imports
- Deletes `App.css`, `index.css`, `logo.svg`, `setupTests`, `reportWebVitals`
- Optionally creates `components/`, `pages/`, `hooks/`, `services/`, `utils/`, `assets/`, `styles/`

## Requirements

- Node.js >= 18
- Internet connection (runs `create-vite` or `create-react-app` under the hood)

## License

MIT